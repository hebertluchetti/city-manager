##############################################################################
# Avaliação PSQL Pratica - Exercício 1 - SCRIPT1.SQL
# Hebert Luchetti Ribeiro - 23/08/2021
# Formato MySQL
##############################################################################
# 
#  Crie as seguintes tabelas, em um script SQL com o nome de SCRIPT1.SQL:
##############################################################################
DROP TABLE IF EXISTS exame_item_nf;
DROP TABLE IF EXISTS exame_nf;

CREATE TABLE exame_nf
	(
	  id_nf         DECIMAL(10,0) NOT NULL,
	  numero        DECIMAL(10,0) NOT NULL,
	  data_cadastro DATE NOT NULL,
	  total_geral   DECIMAL(15,2) NOT NULL
	);
ALTER TABLE exame_nf ADD ( CONSTRAINT pk_exame_nf PRIMARY KEY ( id_nf ) );

CREATE TABLE exame_item_nf
	 (
		  id_item_nf  DECIMAL(10,0) NOT NULL,
		  id_nf       DECIMAL(10,0) NOT NULL,
		  id_produto  DECIMAL(10,0) NOT NULL,
		  qtd         DECIMAL(10,0) NOT NULL,
		  valor       DECIMAL(15,2) NOT NULL
	 );
ALTER TABLE exame_item_nf ADD (CONSTRAINT pk_exame_item_nf PRIMARY KEY ( id_item_nf ));
ALTER TABLE exame_item_nf ADD (CONSTRAINT fk_exame_item_nf FOREIGN KEY ( id_nf ) REFERENCES exame_nf ( id_nf ));