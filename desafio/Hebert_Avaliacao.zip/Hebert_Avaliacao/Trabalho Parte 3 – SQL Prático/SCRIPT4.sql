##################################################################
# Avaliação PSQL Pratica - Exercício 4 - SCRIPT4.SQL
# Hebert Luchetti Ribeiro - 23/08/2021
# Formato MySQL
##################################################################
#
# Crie uma consulta SELECT que exiba o total de linhas da tabela EXAME_NF por dia. 
# Exiba somente as linhas que possuam ao menos um item (EXAME_ITEMNF) com valor inferior a 50. 
# Salve a consulta no arquivo SCRIPT4.SQL.
##################################################################
SELECT ef.data_cadastro,
       COUNT(ef.id_nf) AS total_linhas
 FROM  exame_nf ef
WHERE ef.id_nf IN 
			(
				SELECT id_nf
				FROM   exame_item_nf
				WHERE  valor < 50
			)
GROUP BY ef.data_cadastro 
ORDER BY ef.data_cadastro;