##################################################################
# Avaliação PSQL Pratica - Exercício 5 - SCRIPT5.SQL
# Hebert Luchetti Ribeiro - 23/08/2021
# Formato MySQL
##################################################################
# 
# Otimize a última consulta SELECT (Exercício 4), 
# medindo o custo e melhore caso seja possível. 
# Crie índices caso necessário. 
# Salve todas alterações, caso existam, no arquivo SCRIPT5.SQL
##################################################################

EXPLAIN
SELECT ef.data_cadastro,
       COUNT(ef.id_nf) AS total
FROM   exame_nf ef
WHERE  ef.id_nf IN (
				SELECT
                    CASE WHEN valor < 50 THEN id_nf END
				FROM  exame_item_nf)
GROUP  BY ef.data_cadastro 
ORDER  BY ef.data_cadastro;

ALTER TABLE exame_item_nf ADD INDEX indice_ef1 (id_nf,id_item_nf);
ALTER TABLE exame_item_nf ADD INDEX indice_ef2 (id_item_nf);

