#################################################################################
# Avaliação PSQL Pratica - Exercício 2 - SCRIPT2.SQL
# Hebert Luchetti Ribeiro - 23/08/2021
# Formato MySQL
#################################################################################
# 
# Crie um segundo script (SCRIPT2.SQL) que possua um bloco de código para que gere registros fictícios para as tabelas criadas. 
# Gere 1000 registros para a tabela EXAME_NF.  
# Para cada EXAME_NF gere 3 registros.  
# Faça com que a DATACADASTRO do EXAME_NF comece em 10 dias atrás,  
# fazendo com que a cada 100 registros a data seja aumentada em 1 dia, 
# distribuindo assim os 1000 registros em 10 dias diferentes de cadastro. 
#################################################################################
DROP PROCEDURE IF EXISTS populate_tables;

DELIMITER $$
CREATE PROCEDURE populate_tables()
BEGIN
    DECLARE random_numero INT DEFAULT 1;
    DECLARE exist_one INT DEFAULT 0;
    DECLARE qt INT DEFAULT 0;
    DECLARE i INT DEFAULT 0;
    DECLARE counter INT DEFAULT 1;
    DECLARE idnf INT DEFAULT 0;
    DECLARE iditemnf INT DEFAULT 1;
    DECLARE dt DATE DEFAULT DATE_SUB(current_date(), INTERVAL 10 day);
	
    WHILE counter <= 1000 DO
		IF qt = 100 THEN
			  SET dt = DATE_ADD(dt,INTERVAL 1 day);
			  SET qt = 0;
		END IF;
	   
		SET exist_one = 1;
		WHILE exist_one > 0 DO
			SET random_numero = FLOOR(RAND()*2500);
			SELECT COUNT(*) INTO exist_one
			 FROM exame_nf as ef
			WHERE ef.numero = random_numero;
		END WHILE;    
        
		INSERT INTO exame_nf (id_nf, numero, data_cadastro, total_geral) 
		VALUES(counter, random_numero, dt, 0);
       
		SET i = 0;
		WHILE i < 3 DO
			SET i = i + 1;

            INSERT INTO exame_item_nf (id_item_nf, id_nf, id_produto, qtd, valor)
			VALUES ( 
					iditemnf,
					counter, 
					FLOOR(RAND()*100000), 
					FLOOR(RAND()*100), 
					(RAND()*120.23)
                   );
                   
			SET iditemnf = iditemnf+1;
        END WHILE;
        
		UPDATE exame_nf
         SET total_geral = 
         ( 
			SELECT SUM(valor)
			 FROM exame_item_nf
			WHERE id_nf = counter
		)
        WHERE id_nf = counter;
        
		SET counter = counter + 1;
        SET qt = qt + 1;
    END WHILE;
END$$
DELIMITER ;

CALL populate_tables();








