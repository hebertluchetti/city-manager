##################################################################
# Avaliação PSQL Pratica - Exercício 3 - SCRIPT3.SQL
# Hebert Luchetti Ribeiro - 23/08/2021
# Formato MySQL
##################################################################
#
# Crie uma procedure chamada DEFINIR_VALORES para que altere o valor dos itens da tabela EXAME_ITEMNF, 
# definindo números inteiros aleatórios entre 1 e 100. 
# Faça com que a linha da tabela EXAME_NF receba o valor da somatória de seus itens na coluna TOTALGERAL. 
# Salve o fonte do script no arquivo SCRIPT3.SQL.
##################################################################
DROP PROCEDURE IF EXISTS definir_valores;

DELIMITER $$
CREATE PROCEDURE definir_valores()
BEGIN
  BEGIN
	  DECLARE fim1 INT DEFAULT 0; 
	  DECLARE v1_id_item_nf, v1_id_nf  DECIMAL(10,0) DEFAULT 0;

	  DECLARE cursor_item_nf CURSOR FOR 
		SELECT id_item_nf,
			   id_nf
		FROM exame_item_nf;
	  DECLARE CONTINUE HANDLER FOR NOT FOUND SET fim1 = 1; 
	 
	  OPEN cursor_item_nf;
		  WHILE (fim1 != 1) DO
			FETCH cursor_item_nf INTO v1_id_item_nf, v1_id_nf;
		  
			UPDATE exame_item_nf
			  SET valor = (RAND()*100)
			WHERE id_item_nf = v1_id_item_nf;
		 
		  END WHILE;
	  CLOSE cursor_item_nf;
  END;
  
  BEGIN   
	  DECLARE fim2 INT DEFAULT 0; 
	  DECLARE v2_id_nf DECIMAL(10,0) DEFAULT 0;
	  
	  DECLARE cursor_nf CURSOR FOR 
		SELECT id_nf
		FROM exame_nf;
		
	  DECLARE CONTINUE HANDLER FOR NOT FOUND  SET fim2 = 1; 
	  
	  OPEN cursor_nf;
		  itemLoop2: LOOP
			FETCH cursor_nf INTO v2_id_nf;
			
			IF fim2 THEN
				 LEAVE itemLoop2;
			END IF;
			
			UPDATE exame_nf
			 SET total_geral =
						(
							SELECT SUM(valor)
							 FROM exame_item_nf
							WHERE id_nf = v2_id_nf
						)
			WHERE id_nf = v2_id_nf;

		  END LOOP itemLoop2;
	  CLOSE cursor_nf;
  END;
END $$
DELIMITER ;

CALL definir_valores();