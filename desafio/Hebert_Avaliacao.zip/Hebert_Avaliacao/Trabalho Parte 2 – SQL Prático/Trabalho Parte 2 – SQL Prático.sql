###################################################
# Exercicio1  de Hebert Luchetti Ribeiro 23/08/2021 #
###################################################
# Parte 2 – SQL Prático
# Exercício 1.
# Scripts formato MySQL
###################################################

CREATE TABLE `produto` (
  `id-produto` decimal(15,0) NOT NULL ,
  `codigo-interno` varchar(60) NOT NULL,
  `descricao` varchar(120) NOT NULL DEFAULT '',
  `ativo` boolean NOT NULL DEFAULT true,
  PRIMARY KEY (`id-produto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `embalagem` (
  `id-produto` decimal(15,0) NOT NULL ,
  `barra` varchar(32) NOT NULL,
  `descricao` varchar(80) NOT NULL DEFAULT '',
  `fator-conversao` decimal(15,0) NOT NULL,
  `altura` decimal(15,0) NOT NULL,
  `largura` decimal(15,0) NOT NULL,
   `comprimento` decimal(15,0) unsigned NOT NULL,
   `ativo` boolean NOT NULL DEFAULT true,
  PRIMARY KEY (`id-produto`,`barra`),
  KEY `id-produto` (`id-produto`),
  CONSTRAINT `fk-id-produto` FOREIGN KEY (`id-produto`) REFERENCES `produto` (`id-produto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/* Dados da tabela produto */
INSERT INTO `produto` 
(`id-produto`,`codigo-interno`,`descricao`,`ativo`)
VALUES
(12,'000001','OLEO DE SOJA',1),
(13,'000002','OLEO DE GIRASSOL',1),
(57,'000003','TELEFONE SEM FIO',1),
(382,'000004','MOUSE MICROSOFT',1),
(435,'000005','JOHNNIE WALKER BLUE LABEL',1);

/* Dados da tabela embalagem */
INSERT INTO `embalagem`
(`id-produto`,`barra`,`descricao`,`fator-conversao`,`altura`,`largura`,`comprimento`,`ativo`)
VALUES
(12,'7891000315507','OLEO DE SOJA LT',1,200,100,100,1),
(12,'7891000315508','OLEO DE SOJA CX COM 10',10,250,400,400,1),
(13,'7891000415510','OLEO DE GIRASSOL LT',1,200,100,100,1),
(13,'7891000415511','OLEO DE GIRASSOL CX COM 10',10,250,400,400,1),
(57,'7891000415515','TELEFONE SEM FIO',1,170,180,190,1),
(382,'7891000715501','MOUSE MICROSOFT',1,60,60,110,1),
(382,'7891000715502','MOUSE MICROSOFT CX COM 10',10,180,200,200,1),
(382,'7891000715503','MOUSE MICROSOFT CX COM 50',50,400,450,450,0),
(435,'7891000745678','JOHNNIE WALKER BLUE LABEL',1,300,150,150,1),
(435,'7891000745679','JOHNNIE WALKER BLUE LABEL CX COM 12',12,350,450,450,1);

#### Consultas
# a)  Uma consulta onde mostre os 10 primeiros produtos.
SELECT * 
 FROM produto 
LIMIT 10;

#  b) Uma consulta onde mostre os produtos apenas com embalagens ativas.
SELECT p.*
 FROM `produto` AS p
 JOIN `embalagem` AS m ON (p.`id-produto` = m.`id-produto` and m.ativo = 1)
 GROUP BY p.`id-produto`;

#  c) Uma consulta que traga quantidade de embalagens de cada produto.
SELECT  p.`id-produto`, p.`descricao`, COUNT(m.`id-produto`)
 FROM `produto` AS p
 JOIN `embalagem` AS m ON (p.`id-produto` = m.`id-produto`)
 GROUP BY p.`id-produto`;

#  d) Insira um novo produto e uma nova embalagem para esse produto de acordo com a estrutura dados.
INSERT INTO `produto` 
(`id-produto`,`codigo-interno`,`descricao`,`ativo`)
VALUES
(999,'000099','OLEO DE OLIVA',1);

INSERT INTO `embalagem`
(`id-produto`,`barra`,`descricao`,`fator-conversao`,`altura`,`largura`,`comprimento`,`ativo`)
VALUES
(999,'7891000315599','OLEO DE SOJA OLIVA',1,200,100,100,1);

#  e) Altere a altura para 250, largura para 120 e comprimento para 150 das embalagens dos produtos cujo FATORCONVERSAO seja igual a 1.
SET SQL_SAFE_UPDATES = 0;
UPDATE `embalagem` AS emb
SET
	emb.`altura` = 250,
	emb.`largura` = 120,
	emb.`comprimento` = 150
WHERE (emb.`fator-conversao` = 1 AND emb.`id-produto` IS NOT NULL AND emb.`barra` IS NOT NULL);
SET SQL_SAFE_UPDATES = 1;

